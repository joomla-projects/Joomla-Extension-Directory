SET FOREIGN_KEY_CHECKS = 0;

/* #__jed_vel_abandoned_report row 12 */
/* #__jed_vel_developer_update row 24 */
/* #__jed_vel_report row 3285 */
/* #__jed_vel_vulnerable_item row 11965 */

/*Data for the table `#__jed_vel_abandoned_report` */

/*Data for the table `#__jed_vel_developer_update` */

/*Data for the table `#__jed_vel_report` */

/*Data for the table `#__jed_vel_vulnerable_item` */

SET FOREIGN_KEY_CHECKS = 1;